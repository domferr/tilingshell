
try {

var init = (function (gio2, st1, gobject2, clutter10, meta10, shell0, GLib) {
    'use strict';

    function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

    var GLib__default = /*#__PURE__*/_interopDefaultLegacy(GLib);

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    // Taken from https://github.com/material-shell/material-shell/blob/main/src/utils/gjs.ts
    /// Decorator function to call `GObject.registerClass` with the given class.
    /// Use like
    /// ```
    /// @registerGObjectClass
    /// export class MyThing extends GObject.Object { ... }
    /// ```
    function registerGObjectClass(target) {
        // Note that we use 'hasOwnProperty' because otherwise we would get inherited meta infos.
        // This would be bad because we would inherit the GObjectName too, which is supposed to be unique.
        if (Object.prototype.hasOwnProperty.call(target, 'metaInfo')) {
            // eslint-disable-next-line
            // @ts-ignore
            // eslint-disable-next-line
            return gobject2.registerClass(target.metaInfo, target);
        }
        else {
            // eslint-disable-next-line
            // @ts-ignore
            return gobject2.registerClass(target);
        }
    }

    const logger = (prefix) => (content) => log(`[modernwindowmanager] [${prefix}] ${content}`);
    const getCurrentExtension = () => imports.misc.extensionUtils.getCurrentExtension();
    const getCurrentExtensionSettings = () => imports.misc.extensionUtils.getSettings();
    imports.gettext.domain(getCurrentExtension().metadata.uuid).gettext;

    class TileGroup {
        perc;
        horizontal;
        tiles;
        constructor({ tiles = [], perc = 1.0, horizontal = true }) {
            this.perc = perc;
            this.horizontal = horizontal;
            this.tiles = tiles;
        }
    }

    const global$1 = shell0.Global.get();
    const Main = imports.ui.main;
    const getMonitors = () => imports.ui.main.layoutManager.monitors;
    const addToStatusArea = (button) => {
        imports.ui.main.panel.addToStatusArea(getCurrentExtension().metadata.uuid, button, 1, 'right');
    };
    const isPointInsideRect = (point, rect) => {
        return point.x >= rect.x && point.x <= rect.x + rect.width &&
            point.y >= rect.y && point.y <= rect.y + rect.height;
    };
    const getGlobalPosition = (actor) => {
        if (!actor)
            return { x: 0, y: 0 };
        const parent = actor.get_parent();
        const parentPos = parent === null ? { x: 0, y: 0 } : getGlobalPosition(parent);
        return {
            x: actor.x + parentPos.x,
            y: actor.y + parentPos.y,
        };
    };
    const buildTileMargin = (tilePos, innerMargin, outerMargin, containerRect) => {
        const isLeft = tilePos.x === containerRect.x;
        const isTop = tilePos.y === containerRect.y;
        const isRight = tilePos.x + tilePos.width === containerRect.x + containerRect.width;
        const isBottom = tilePos.y + tilePos.height === containerRect.y + containerRect.height;
        return new clutter10.Margin({
            top: isTop ? outerMargin.top : innerMargin.top / 2,
            bottom: isBottom ? outerMargin.bottom : innerMargin.bottom / 2,
            left: isLeft ? outerMargin.left : innerMargin.left / 2,
            right: isRight ? outerMargin.right : innerMargin.right / 2,
        });
    };

    const debug$2 = logger(`LayoutWidget`);
    // A widget to draw layouts
    let LayoutWidget = class LayoutWidget extends st1.Widget {
        _previews;
        _containerRect;
        _layout;
        _innerMargin;
        _outerMargin;
        constructor(parent, layout, innerMargin, outerMargin, containerRect, style_class = "") {
            super({ style_class });
            if (parent)
                parent.add_child(this);
            this._previews = [];
            this._containerRect = new meta10.Rectangle();
            this._layout = new TileGroup({ tiles: [] });
            this._innerMargin = new clutter10.Margin();
            this._outerMargin = new clutter10.Margin();
            this.relayout({ containerRect, layout, innerMargin, outerMargin });
        }
        build_layout(groupRect, group, previews, innerMargin, outerMargin, containerRect) {
            if (group.tiles.length == 0) {
                const tileMargin = buildTileMargin(groupRect, innerMargin, outerMargin, containerRect);
                const tile = this.buildTile(this, groupRect.copy(), tileMargin);
                previews.push(tile);
                return previews;
            }
            const workingRect = groupRect.copy();
            group.tiles.forEach((innerGroup, index) => {
                let innerGroupRect = new meta10.Rectangle({
                    x: workingRect.x,
                    y: workingRect.y,
                    width: group.horizontal ? groupRect.width * innerGroup.perc : groupRect.width,
                    height: group.horizontal ? groupRect.height : groupRect.height * innerGroup.perc,
                });
                // if there is remaining width or height, then we have lost some pixel because of
                // floating point precision. Ensure the remaining width or height is given to the last tile
                if (index === group.tiles.length - 1) {
                    // ensure we don't go beyond the limits and ensure the remaining 
                    // width or height is given to the last tile
                    innerGroupRect.width = groupRect.x + groupRect.width - innerGroupRect.x;
                    innerGroupRect.height = groupRect.y + groupRect.height - innerGroupRect.y;
                }
                this.build_layout(innerGroupRect, innerGroup, previews, innerMargin, outerMargin, containerRect);
                workingRect.x += group.horizontal ? innerGroupRect.width : 0;
                workingRect.y += group.horizontal ? 0 : innerGroupRect.height;
            });
            return previews;
        }
        buildTile(parent, rect, margin) {
            throw ("This class shouldn't be instantiated but be extended instead");
        }
        relayout(params) {
            var trigger_relayout = false;
            if (params?.innerMargin) {
                this._innerMargin = params.innerMargin.copy();
                trigger_relayout = true;
            }
            if (params?.outerMargin && this._outerMargin !== params.outerMargin) {
                this._outerMargin = params.outerMargin.copy();
                trigger_relayout = true;
            }
            if (params?.layout && this._layout !== params.layout) {
                this._layout = params.layout;
                trigger_relayout = true;
            }
            if (params?.containerRect && this._containerRect !== params.containerRect) {
                this._containerRect = params.containerRect.copy();
                trigger_relayout = true;
            }
            if (!trigger_relayout) {
                debug$2("relayout not needed");
                return;
            }
            this._previews?.forEach((preview) => preview.destroy());
            this.remove_all_children();
            this._previews = [];
            if (this._containerRect.width === 0 || this._containerRect.height === 0)
                return;
            this._previews = this.build_layout(this._containerRect, this._layout, [], this._innerMargin, this._outerMargin, this._containerRect);
            this._previews.forEach((lay) => lay.open());
        }
    };
    LayoutWidget = __decorate([
        registerGObjectClass
    ], LayoutWidget);

    const WINDOW_ANIMATION_TIME = 100;
    let TilePreview = class TilePreview extends st1.Widget {
        _margins;
        _showing;
        _rect;
        constructor(parent, rect, margins) {
            super();
            this._rect = rect ? rect : new meta10.Rectangle({ width: 0 });
            this._margins = margins ? margins : new clutter10.Margin();
            parent.add_child(this);
        }
        set margins(margins) {
            this._margins = margins;
        }
        _init() {
            super._init();
            this.set_style_class_name('tile-preview custom-tile-preview');
            this.hide();
            this._showing = false;
        }
        get innerX() {
            return this._rect.x + this._margins.left;
        }
        get innerY() {
            return this._rect.y + this._margins.top;
        }
        get innerWidth() {
            return this._rect.width - this._margins.right - this._margins.left;
        }
        get innerHeight() {
            return this._rect.height - this._margins.top - this._margins.bottom;
        }
        get rect() {
            return this._rect;
        }
        set rect(newRect) {
            this._rect = newRect;
            this.set_size(this._rect.width, this._rect.height);
            this.set_position(this._rect.x, this._rect.y);
        }
        open(ease = false, position) {
            if (position) {
                this._rect = position;
            }
            /*debug(
              `open tile -> x: ${this._rect.x}, y: ${this._rect.y}, width: ${this._rect.width}, height: ${this._rect.height}`,
            );*/
            this._showing = true;
            this.show();
            // @ts-ignore
            this.ease({
                x: this.innerX,
                y: this.innerY,
                width: this.innerWidth,
                height: this.innerHeight,
                opacity: 255,
                duration: ease ? WINDOW_ANIMATION_TIME : 0,
                mode: clutter10.AnimationMode.EASE_OUT_QUAD,
            });
        }
        openBelow(window, ease = false, position) {
            if (this.get_parent() === global$1.window_group) {
                let windowActor = window.get_compositor_private();
                if (!windowActor)
                    return;
                global$1.window_group.set_child_below_sibling(this, windowActor);
            }
            if (this._rect.width === 0) {
                const window_rect = window.get_frame_rect();
                this.set_size(window_rect.width, window_rect.height);
                this.set_position(window_rect.x, window_rect.y);
                this.opacity = 0;
            }
            this.open(ease, position);
        }
        openAbove(window, ease = false, position) {
            if (this.get_parent() === global$1.window_group) {
                let windowActor = window.get_compositor_private();
                if (!windowActor)
                    return;
                global$1.window_group.set_child_above_sibling(this, windowActor);
            }
            if (this._rect.width === 0) {
                const window_rect = window.get_frame_rect();
                this.set_size(window_rect.width, window_rect.height);
                this.set_position(window_rect.x, window_rect.y);
                this.opacity = 0;
            }
            this.open(ease, position);
        }
        close() {
            if (!this._showing)
                return;
            this._showing = false;
            // @ts-ignore
            this.ease({
                opacity: 0,
                duration: WINDOW_ANIMATION_TIME,
                mode: clutter10.AnimationMode.EASE_OUT_QUAD,
                onComplete: () => this.hide(),
            });
        }
        destroy() {
            //debug(`destroy tile at position { x: ${this.x}, y: ${this.y} }`);
            super.destroy();
        }
    };
    TilePreview = __decorate([
        registerGObjectClass
    ], TilePreview);

    let SnapAssistTile = class SnapAssistTile extends TilePreview {
        constructor(parent, rect, margins) {
            super(parent, rect, margins);
        }
        _init() {
            super._init();
            this.set_style_class_name('snap-assist-tile');
        }
    };
    SnapAssistTile = __decorate([
        registerGObjectClass
    ], SnapAssistTile);

    var LayoutSelectionWidget_1;
    const { PopupBaseMenuItem } = imports.ui.popupMenu;
    const { Button: PopupMenuButton } = imports.ui.panelMenu;
    let LayoutSelectionWidget = LayoutSelectionWidget_1 = class LayoutSelectionWidget extends LayoutWidget {
        static _layoutHeight = 36;
        static _layoutWidth = 64; // 16:9 ratio. -> (16*this._snapAssistHeight) / 9 and then rounded to int
        constructor(layout, margin, scaleFactor) {
            const rect = new meta10.Rectangle({ height: LayoutSelectionWidget_1._layoutHeight * scaleFactor, width: LayoutSelectionWidget_1._layoutWidth * scaleFactor, x: 0, y: 0 });
            const margins = new clutter10.Margin({ top: margin * scaleFactor, bottom: margin * scaleFactor, left: margin * scaleFactor, right: margin * scaleFactor });
            super(null, layout, margins, margins, rect, "snap-assist-layout");
        }
        buildTile(parent, rect, margin) {
            return new SnapAssistTile(parent, rect, margin);
        }
    };
    LayoutSelectionWidget = LayoutSelectionWidget_1 = __decorate([
        registerGObjectClass
    ], LayoutSelectionWidget);
    let Indicator = class Indicator extends PopupMenuButton {
        settings;
        icon;
        onLayoutSelected;
        layoutsBoxLayout;
        layoutsButtons = [];
        constructor(onLayoutSelection) {
            super(0.5, 'Modern Window Manager Indicator', false);
            this.onLayoutSelected = onLayoutSelection;
            this.settings = getCurrentExtensionSettings();
            this.icon = new st1.Icon({
                gicon: gio2.icon_new_for_string(`${getCurrentExtension().path}/icons/indicator.svg`),
                style_class: 'system-status-icon indicator-icon',
            });
            this.add_child(this.icon);
            this.layoutsBoxLayout = new st1.BoxLayout({
                name: 'popup-menu-layout-selection',
                x_align: clutter10.ActorAlign.CENTER,
                y_align: clutter10.ActorAlign.CENTER,
                x_expand: true,
                y_expand: true,
                vertical: false
            });
            const layoutsPopupMenu = new PopupBaseMenuItem({ style_class: 'popup-menu-layout-selection' });
            layoutsPopupMenu.add_actor(this.layoutsBoxLayout);
            this.menu.addMenuItem(layoutsPopupMenu);
        }
        setLayouts(layouts, selectedIndex, hasMargins) {
            this.layoutsBoxLayout.remove_all_children();
            const scalingFactor = global.display.get_monitor_scale(Main.layoutManager.primaryIndex);
            this.layoutsButtons = layouts.map((lay, ind) => {
                const btn = new st1.Button({ style_class: "popup-menu-layout-button" });
                btn.child = new LayoutSelectionWidget(lay, hasMargins ? 1 : 0, scalingFactor);
                this.layoutsBoxLayout.add_child(btn);
                btn.connect('clicked', (self) => {
                    this.selectButtonAtIndex(ind, lay);
                    this.menu.toggle();
                });
                return btn;
            });
            this.layoutsButtons[selectedIndex].set_checked(true);
        }
        getSelectedButtonIndex() {
            return this.layoutsButtons.findIndex(btn => btn.checked);
        }
        selectButtonAtIndex(index, layout) {
            this.layoutsButtons.forEach(btn => btn.set_checked(false));
            this.layoutsButtons[index].set_checked(true);
            this.onLayoutSelected(layout);
        }
        destroy() {
            this.layoutsButtons.forEach(btn => btn.destroy());
            this.layoutsButtons = [];
            super.destroy();
        }
    };
    Indicator = __decorate([
        registerGObjectClass
    ], Indicator);

    let BlurTilePreview = class BlurTilePreview extends TilePreview {
        _init() {
            super._init();
            this.add_effect(new shell0.BlurEffect({
                sigma: 4,
                brightness: 1,
                mode: 1, // blur the background of the widget
            }));
        }
    };
    BlurTilePreview = __decorate([
        registerGObjectClass
    ], BlurTilePreview);

    /**
     * A TilingLayout is a group of multiple tile previews. By aggregating all of them,
     * it is possible to easily show and hide each tile at the same time and to get the
     * hovered tile.
     */
    let TilingLayout = class TilingLayout extends LayoutWidget {
        _blur = false;
        _showing;
        constructor(layout, innerMargin, outerMargin, workarea) {
            super(global$1.window_group, layout, innerMargin, outerMargin, workarea);
        }
        _init() {
            super._init();
            this.hide();
            this._showing = false;
        }
        buildTile(parent, rect, margin) {
            return this._blur ? new BlurTilePreview(parent, rect, margin) : new TilePreview(parent, rect, margin);
        }
        get showing() {
            return this._showing;
        }
        openBelow(window) {
            let windowActor = window.get_compositor_private();
            if (!windowActor)
                return;
            global$1.window_group.set_child_below_sibling(this, windowActor);
            this.open();
        }
        openAbove(window) {
            let windowActor = window.get_compositor_private();
            if (!windowActor)
                return;
            global$1.window_group.set_child_above_sibling(this, windowActor);
            this.open();
        }
        open() {
            this.show();
            this._showing = true;
            // @ts-ignore
            this.ease({
                x: this.x,
                y: this.y,
                opacity: 255,
                duration: WINDOW_ANIMATION_TIME,
                mode: clutter10.AnimationMode.EASE_OUT_QUAD,
            });
        }
        close() {
            this._showing = false;
            // @ts-ignore
            this.ease({
                opacity: 0,
                duration: WINDOW_ANIMATION_TIME,
                mode: clutter10.AnimationMode.EASE_OUT_QUAD,
                onComplete: () => this.hide(),
            });
        }
        getTileBelow(currPointerPos) {
            for (let i = 0; i < this._previews.length; i++) {
                let preview = this._previews[i];
                const isHovering = currPointerPos.x >= preview.x && currPointerPos.x <= preview.x + preview.width
                    && currPointerPos.y >= preview.y && currPointerPos.y <= preview.y + preview.height;
                if (isHovering)
                    return preview;
            }
        }
    };
    TilingLayout = __decorate([
        registerGObjectClass
    ], TilingLayout);

    var SnapAssistLayout_1;
    let SnapAssistLayout = SnapAssistLayout_1 = class SnapAssistLayout extends LayoutWidget {
        static _snapAssistHeight = 84;
        static _snapAssistWidth = 150; // 16:9 ratio. -> (16*this._snapAssistHeight) / 9 and then rounded to int
        constructor(parent, layout, margin, scaleFactor) {
            const rect = new meta10.Rectangle({ height: SnapAssistLayout_1._snapAssistHeight * scaleFactor, width: SnapAssistLayout_1._snapAssistWidth * scaleFactor, x: 0, y: 0 });
            const margins = new clutter10.Margin({ top: margin.top * scaleFactor, bottom: margin.bottom * scaleFactor, left: margin.left * scaleFactor, right: margin.right * scaleFactor });
            const outerMargin = Math.min(margin.top, Math.min(margin.bottom, Math.min(margin.left, margin.right))) * scaleFactor;
            super(parent, layout, margins, new clutter10.Margin({ top: outerMargin, bottom: outerMargin, left: outerMargin, right: outerMargin }), rect, "snap-assist-layout");
            this.ensure_style();
        }
        buildTile(parent, rect, margin) {
            return new SnapAssistTile(parent, rect, margin);
        }
        getTileBelow(cursorPos) {
            const globalPos = getGlobalPosition(this);
            for (let i = 0; i < this._previews.length; i++) {
                let preview = this._previews[i];
                const pos = { x: globalPos.x + preview.rect.x, y: globalPos.y + preview.rect.y };
                const isHovering = cursorPos.x >= pos.x && cursorPos.x <= pos.x + preview.rect.width
                    && cursorPos.y >= pos.y && cursorPos.y <= pos.y + preview.rect.height;
                if (isHovering)
                    return preview;
            }
        }
        hide() {
            this.set_height(0);
            this.set_opacity(0);
        }
        show() {
            this.set_height(SnapAssistLayout_1._snapAssistHeight);
            this.set_opacity(255);
        }
        easeHide(params) {
            // @ts-ignore
            this.ease({
                height: 0,
                opacity: 0,
                duration: params.duration,
                mode: params.mode,
            });
        }
        easeShow(params) {
            this.show();
            // @ts-ignore
            this.ease({
                height: SnapAssistLayout_1._snapAssistHeight,
                opacity: 255,
                duration: params.duration,
                mode: params.mode,
            });
        }
    };
    SnapAssistLayout = SnapAssistLayout_1 = __decorate([
        registerGObjectClass
    ], SnapAssistLayout);

    const SNAP_ASSIST_SIGNAL = 'snap-assist';
    const SNAP_ASSIST_ANIMATION_TIME = 180;
    let SnapAssist = class SnapAssist extends st1.BoxLayout {
        static metaInfo = {
            Signals: {
                "snap-assist": {
                    param_types: [meta10.Rectangle.$gtype, gobject2.TYPE_DOUBLE, gobject2.TYPE_DOUBLE]
                },
            },
            GTypeName: "SnapAssist"
        };
        // distance from top when the snap assistant is enlarged
        _enlargedVerticalDistance = 32;
        // cursor's max distance from the snap assistant to enlarge it 
        _activationAreaOffset = 4;
        // height when it is not enlarged (shrinked)
        _shrinkHeight = 16;
        // distance between layouts
        _separatorSize = 8;
        _showing;
        _snapAssistLayouts;
        _isEnlarged = false;
        _rect = new meta10.Rectangle();
        _enlargedRect = new meta10.Rectangle();
        _workArea = new meta10.Rectangle();
        _hoveredTile;
        constructor(parent, layouts, margin, workArea, scaleFactor) {
            super({
                name: 'snap_assist',
                x_align: clutter10.ActorAlign.CENTER,
                y_align: clutter10.ActorAlign.CENTER,
                vertical: false,
                reactive: true,
                style_class: "popup-menu-content snap-assistant",
            });
            this._workArea = workArea;
            if (parent)
                parent.add_child(this);
            this._shrinkHeight *= scaleFactor;
            const layoutMargin = new clutter10.Margin({
                top: margin.top === 0 ? 0 : 2,
                bottom: margin.bottom === 0 ? 0 : 2,
                left: margin.left === 0 ? 0 : 2,
                right: margin.right === 0 ? 0 : 2,
            });
            // build the layouts inside the snap assistant. Place a spacer between each layout
            this._snapAssistLayouts = layouts.map((lay, ind) => {
                const saLay = new SnapAssistLayout(this, lay, layoutMargin, scaleFactor);
                // build and place a spacer
                if (ind < layouts.length - 1) {
                    this.add_child(new st1.Widget({ width: scaleFactor * this._separatorSize, height: 1 }));
                }
                return saLay;
            });
            // ensure the style is applied on all the children such that we can 
            // know the correct size of the entire box layout 
            this._snapAssistLayouts.forEach(lay => lay.ensure_style());
            this.ensure_style();
            const padding = this.get_theme_node().get_padding(st1.Side.BOTTOM);
            const scaledPadding = st1.ThemeContext.get_for_stage(global.get_stage()).get_scale_factor() === 1 ?
                padding * scaleFactor : padding;
            this.set_style(`
            padding: ${scaledPadding}px !important;
        `);
            /*const color = this.get_theme_node().get_background_color();
            const newAlpha = 220;
            background-color: rgba(${color.red}, ${color.green}, ${color.blue}, ${newAlpha / 255}) !important;
            */
            this.ensure_style();
            this._enlargedRect.height = this.size.height;
            this._enlargedRect.width = this.size.width;
            this._snapAssistLayouts.forEach(lay => lay.hide());
            this.set_opacity(0);
            this.hide();
            this._showing = false;
            this.enlarged = false;
        }
        set workArea(newWorkArea) {
            this._workArea = newWorkArea;
            this.enlarged = this._isEnlarged;
            this.set_position(this._rect.x, this._rect.y);
        }
        set enlarged(newVal) {
            this._isEnlarged = newVal;
            this._rect.width = this._enlargedRect.width;
            this._rect.height = this._isEnlarged ? this._enlargedRect.height : this._shrinkHeight;
            this._rect.x = this._workArea.x + (this._workArea.width / 2) - (this._rect.width / 2);
            this._rect.y = this._workArea.y + (this._isEnlarged ? this._enlargedVerticalDistance : 0);
        }
        get isEnlarged() {
            return this._isEnlarged;
        }
        close() {
            if (!this._showing)
                return;
            this._showing = false;
            this.enlarged = false;
            if (!this._isEnlarged) {
                this._snapAssistLayouts.forEach(lay => lay.easeHide({
                    duration: SNAP_ASSIST_ANIMATION_TIME / 2,
                    mode: clutter10.AnimationMode.EASE_OUT_QUINT,
                }));
            }
            // @ts-ignore
            this.ease({
                x: this._rect.x,
                y: this._rect.y,
                height: this._rect.height,
                opacity: 0,
                duration: SNAP_ASSIST_ANIMATION_TIME,
                delay: SNAP_ASSIST_ANIMATION_TIME,
                mode: clutter10.AnimationMode.EASE_OUT_QUAD,
                onComplete: () => {
                    this.enlarged = false;
                    this.hide();
                    if (this._isEnlarged) {
                        this.add_style_class_name("enlarged");
                    }
                    else {
                        this.remove_style_class_name("enlarged");
                    }
                }
            });
        }
        open(ease = false) {
            this.show();
            if (!this._showing) {
                this._snapAssistLayouts.forEach(lay => lay.hide());
            }
            else if (!this._isEnlarged) {
                this._snapAssistLayouts.forEach(lay => lay.easeHide({
                    duration: SNAP_ASSIST_ANIMATION_TIME / 2,
                    mode: clutter10.AnimationMode.EASE_OUT_QUINT
                }));
            }
            this._showing = true;
            // @ts-ignore
            this.ease({
                x: this._rect.x,
                y: this._rect.y,
                height: this._rect.height,
                opacity: 255,
                duration: ease ? SNAP_ASSIST_ANIMATION_TIME : 0,
                mode: clutter10.AnimationMode.EASE_OUT_QUAD,
                onComplete: () => {
                    if (this._isEnlarged) {
                        this._snapAssistLayouts.forEach(lay => lay.easeShow({
                            duration: SNAP_ASSIST_ANIMATION_TIME,
                            mode: clutter10.AnimationMode.EASE_OUT_CUBIC
                        }));
                        this.add_style_class_name("enlarged");
                    }
                    else {
                        this.remove_style_class_name("enlarged");
                    }
                }
            });
        }
        onMovingWindow(window, ease = false, currPointerPos) {
            const wasEnlarged = this._isEnlarged;
            this.handleOpening(window, ease, currPointerPos);
            if (!this._showing || !this._isEnlarged) {
                if (this._hoveredTile) {
                    this._hoveredTile.set_hover(false);
                }
                this._hoveredTile = undefined;
                if (wasEnlarged)
                    this.emit(SNAP_ASSIST_SIGNAL, new meta10.Rectangle(), 0, 0);
                return;
            }
            const { changed, layout } = this.handleTileHovering(currPointerPos);
            if (changed) {
                const tileRect = this._hoveredTile ? this._hoveredTile.rect : new meta10.Rectangle();
                const layoutRect = this._hoveredTile ? new meta10.Rectangle({ x: layout?.x, y: layout?.y, width: layout?.width, height: layout?.height }) : new meta10.Rectangle();
                this.emit(SNAP_ASSIST_SIGNAL, tileRect, layoutRect.width, layoutRect.height);
            }
        }
        handleOpening(window, ease = false, currPointerPos) {
            if (!this._showing) {
                if (this.get_parent() === global.window_group) {
                    let windowActor = window.get_compositor_private();
                    if (!windowActor)
                        return;
                    global.window_group.set_child_above_sibling(this, windowActor);
                }
            }
            const isNear = this.isBetween(this._rect.x - this._activationAreaOffset, currPointerPos.x, this._rect.x + this.width + this._activationAreaOffset)
                && this.isBetween(this._workArea.y - this._activationAreaOffset, currPointerPos.y, this._workArea.y + this._enlargedVerticalDistance + this.height + this._activationAreaOffset);
            if (this._showing && this._isEnlarged === isNear)
                return;
            this.enlarged = isNear;
            this.open(ease);
        }
        handleTileHovering(currPointerPos) {
            if (!this._isEnlarged) {
                const changed = this._hoveredTile !== undefined;
                if (this._hoveredTile) {
                    this._hoveredTile.set_hover(false);
                }
                this._hoveredTile = undefined;
                return {
                    changed: changed,
                    layout: undefined
                };
            }
            var newTileHovered = undefined;
            var newTileLayout = undefined;
            for (let index = 0; index < this._snapAssistLayouts.length; index++) {
                const snapAssistLay = this._snapAssistLayouts[index];
                newTileHovered = snapAssistLay.getTileBelow(currPointerPos);
                if (newTileHovered) {
                    newTileLayout = snapAssistLay;
                    break;
                }
            }
            const tileChanged = newTileHovered !== this._hoveredTile;
            if (tileChanged) {
                this._hoveredTile?.set_hover(false);
                this._hoveredTile = newTileHovered;
            }
            if (this._hoveredTile)
                this._hoveredTile.set_hover(true);
            return {
                changed: tileChanged,
                layout: newTileLayout
            };
        }
        isBetween(min, num, max) {
            return min <= num && num <= max;
        }
    };
    SnapAssist = __decorate([
        registerGObjectClass
    ], SnapAssist);

    let SelectionTilePreview = class SelectionTilePreview extends TilePreview {
        _backgroundColor = null;
        constructor(parent, rect, margins) {
            super(parent, rect, margins);
        }
        _ensureBackgroundIsSet() {
            // delay setting up the background color so we are sure that the gnome shell theme was applied
            if (this._backgroundColor !== null)
                return;
            this._backgroundColor = this.get_theme_node().get_background_color();
            //debug(`constructor, tile color is ${this._backgroundColor.red} ${this._backgroundColor.green} ${this._backgroundColor.blue} ${this._backgroundColor.alpha}`);
            // since an alpha value lower than 160 is not so much visible, enforce a minimum value of 160
            let newAlpha = Math.max(Math.min(this._backgroundColor.alpha + 35, 255), 160);
            // The final alpha value is divided by 255 since CSS needs a value from 0 to 1, but ClutterColor expresses alpha from 0 to 255
            this.set_style(`
      background-color: rgba(${this._backgroundColor.red}, ${this._backgroundColor.green}, ${this._backgroundColor.blue}, ${newAlpha / 255}) !important;
    `);
            this.remove_style_class_name("tile-preview");
        }
        open(ease = false, position) {
            this._ensureBackgroundIsSet();
            super.open(ease, position);
        }
        openBelow(window, ease = false, position) {
            this._ensureBackgroundIsSet();
            super.openBelow(window, ease, position);
        }
        openAbove(window, ease = false, position) {
            this._ensureBackgroundIsSet();
            super.openAbove(window, ease, position);
        }
    };
    SelectionTilePreview = __decorate([
        registerGObjectClass
    ], SelectionTilePreview);

    const SIGNAL_GRAB_OP_BEGIN = 'grab-op-begin';
    const SIGNAL_GRAB_OP_END = 'grab-op-end';
    class TilingManager {
        _monitor;
        _selectedTilesPreview;
        _snapAssist;
        _tilingLayout;
        _workArea;
        _innerMargin;
        _outerMargin;
        _isGrabbingWindow;
        _movingWindowTimerDuration = 15;
        _lastCursorPos = null;
        _wasAltPressed;
        _wasCtrlPressed;
        _isSnapAssisting;
        _movingWindowTimerId = null;
        _signalsIds = {};
        _debug;
        /**
         * Constructs a new TilingManager instance.
         * @param monitor The monitor to manage tiling for.
         * @param layouts Available tiling layouts.
         * @param selectedLayout Index of the selected layout.
         * @param innerMargin Inner margin for tiling.
         * @param outerMargin Outer margin for tiling.
         */
        constructor(monitor, layouts, selectedLayout, innerMargin, outerMargin) {
            this._monitor = monitor;
            this._debug = logger(`TilingManager ${monitor.index}`);
            // handle scale factor of the monitor
            var scaleFactor = st1.ThemeContext.get_for_stage(global$1.get_stage()).get_scale_factor();
            if (scaleFactor === 1)
                scaleFactor = global$1.display.get_monitor_scale(monitor.index);
            this._debug(`monitor ${monitor.index} scale factor is ${global$1.display.get_monitor_scale(monitor.index)} and ThemeContext scale factor is ${st1.ThemeContext.get_for_stage(global$1.get_stage()).get_scale_factor()}`);
            // scale margins by scale factor
            this._innerMargin = innerMargin.copy();
            this._innerMargin.top *= scaleFactor;
            this._innerMargin.bottom *= scaleFactor;
            this._innerMargin.left *= scaleFactor;
            this._innerMargin.right *= scaleFactor;
            this._outerMargin = outerMargin.copy();
            this._outerMargin.top *= scaleFactor;
            this._outerMargin.bottom *= scaleFactor;
            this._outerMargin.left *= scaleFactor;
            this._outerMargin.right *= scaleFactor;
            // get the monitor's workarea
            this._workArea = Main.layoutManager.getWorkAreaForMonitor(monitor.index);
            this._debug(`Work area for monitor ${monitor.index}: ${this._workArea.x} ${this._workArea.y} ${this._workArea.width}x${this._workArea.height}`);
            // build the tiling layout
            this._tilingLayout = new TilingLayout(layouts[selectedLayout], this._innerMargin, this._outerMargin, this._workArea);
            // build the snap assistant
            this._snapAssist = new SnapAssist(global$1.window_group, layouts, this._innerMargin, this._workArea, scaleFactor);
            // build the selection tile
            this._selectedTilesPreview = new SelectionTilePreview(global$1.window_group);
            this._selectedTilesPreview.margins = this._innerMargin.copy();
        }
        /**
         * Enables tiling manager by setting up event listeners:
         *  - handle any window's grab begin.
         *  - handle any window's grab end.
         *  - handle grabbed window's movement.
         */
        enable() {
            if (!this._signalsIds[SIGNAL_GRAB_OP_BEGIN]) {
                this._signalsIds[SIGNAL_GRAB_OP_BEGIN] = global$1.display.connect(SIGNAL_GRAB_OP_BEGIN, (_display, window, grabOp) => {
                    if (grabOp != meta10.GrabOp.MOVING)
                        return;
                    this._onWindowGrabBegin(window);
                });
            }
            if (!this._signalsIds[SIGNAL_GRAB_OP_END]) {
                this._signalsIds[SIGNAL_GRAB_OP_END] = global$1.display.connect(SIGNAL_GRAB_OP_END, (_display, window, grabOp) => {
                    if (grabOp != meta10.GrabOp.MOVING)
                        return;
                    if (!window.allows_resize() || !window.allows_move())
                        return;
                    this._onWindowGrabEnd(window);
                });
            }
            if (!this._signalsIds[SNAP_ASSIST_SIGNAL]) {
                this._signalsIds[SNAP_ASSIST_SIGNAL] = this._snapAssist.connect(SNAP_ASSIST_SIGNAL, (_, rect, w, h) => this._onSnapAssist(rect, w, h));
            }
        }
        /**
         * Destroys the tiling manager and cleans up resources.
         */
        destroy() {
            if (this._movingWindowTimerId) {
                GLib.Source.remove(this._movingWindowTimerId);
                this._movingWindowTimerId = null;
            }
            if (this._signalsIds[SIGNAL_GRAB_OP_BEGIN]) {
                global$1.display.disconnect(this._signalsIds[SIGNAL_GRAB_OP_BEGIN]);
                delete this._signalsIds[SIGNAL_GRAB_OP_BEGIN];
            }
            if (this._signalsIds[SIGNAL_GRAB_OP_END]) {
                global$1.display.disconnect(this._signalsIds[SIGNAL_GRAB_OP_END]);
                delete this._signalsIds[SIGNAL_GRAB_OP_END];
            }
            if (this._signalsIds[SNAP_ASSIST_SIGNAL]) {
                this._snapAssist.disconnect(this._signalsIds[SNAP_ASSIST_SIGNAL]);
                delete this._signalsIds[SNAP_ASSIST_SIGNAL];
            }
            this._isGrabbingWindow = false;
            this._isSnapAssisting = false;
            this._tilingLayout.destroy();
            this._snapAssist.destroy();
            this._selectedTilesPreview.destroy();
        }
        set workArea(newWorkArea) {
            if (newWorkArea.equal(this._workArea))
                return;
            this._workArea = newWorkArea;
            this._debug(`new work area for monitor ${this._monitor.index}: ${newWorkArea.x} ${newWorkArea.y} ${newWorkArea.width}x${newWorkArea.height}`);
            // notify the tiling layout that the workarea changed and trigger a new relayout
            // so we will have the layout already computed to be shown quickly when needed
            this._tilingLayout.relayout({ containerRect: this._workArea });
            this._snapAssist.workArea = this._workArea;
        }
        /**
         * Sets the active tiling layout.
         * @param layout The layout to set as active.
         */
        setActiveLayout(layout) {
            this._tilingLayout.relayout({ layout });
        }
        _onWindowGrabBegin(window) {
            this._isGrabbingWindow = true;
            this._movingWindowTimerId = GLib.timeout_add(GLib.PRIORITY_DEFAULT_IDLE, this._movingWindowTimerDuration, this._onMovingWindow.bind(this, window));
            this._onMovingWindow(window);
        }
        _onMovingWindow(window) {
            if (!this._isGrabbingWindow) {
                this._movingWindowTimerId = null;
                return GLib.SOURCE_REMOVE;
            }
            if (!window.allows_resize() || !window.allows_move() || !this._isPointerInsideThisMonitor()) {
                this._tilingLayout.close();
                this._selectedTilesPreview.close();
                this._snapAssist.close();
                this._isSnapAssisting = false;
                return GLib.SOURCE_CONTINUE;
            }
            const [x, y] = global$1.get_pointer();
            const currPointerPos = { x, y };
            // ensure we handle window movement only when needed
            // if the ALT key status is not changed and the mouse is on the same position as before
            // and the CTRL key status is not changed, we have nothing to do
            const isAltPressed = (global$1.get_pointer()[2] & clutter10.ModifierType.MOD1_MASK) != 0;
            const isCtrlPressed = (global$1.get_pointer()[2] & clutter10.ModifierType.CONTROL_MASK) != 0;
            if (this._lastCursorPos !== null && isAltPressed == this._wasAltPressed &&
                currPointerPos.x === this._lastCursorPos.x && currPointerPos.y === this._lastCursorPos.y
                && isCtrlPressed == this._wasCtrlPressed) {
                return GLib.SOURCE_CONTINUE;
            }
            this._lastCursorPos = currPointerPos;
            this._wasCtrlPressed = isCtrlPressed;
            if (!isCtrlPressed) {
                this._snapAssist.onMovingWindow(window, true, currPointerPos);
                // if CTRL is no longer pressed but the layout is still visible, then close it and close the selection
                if (this._tilingLayout.showing) {
                    this._tilingLayout.close();
                    this._selectedTilesPreview.close();
                    this._selectedTilesPreview.rect = new meta10.Rectangle({ width: 0 });
                    this._debug("hide layout");
                }
                return GLib.SOURCE_CONTINUE;
            }
            else {
                // CTRL is pressed, close snap assistance
                this._snapAssist.close();
                if (this._isSnapAssisting)
                    this._selectedTilesPreview.close();
                this._isSnapAssisting = false;
            }
            if (!this._tilingLayout.showing) {
                this._debug("open layout below grabbed window");
                this._tilingLayout.openAbove(window);
            }
            // if the pointer is inside the current selection and alt key status is not changed, then there is nothing to do 
            if (isAltPressed == this._wasAltPressed && isPointInsideRect(currPointerPos, this._selectedTilesPreview.rect)) {
                return GLib.SOURCE_CONTINUE;
            }
            this._wasAltPressed = isAltPressed;
            const tileBelow = this._tilingLayout.getTileBelow(currPointerPos);
            if (!tileBelow)
                return GLib.SOURCE_CONTINUE;
            let selectionRect = tileBelow.rect.copy();
            if (isAltPressed) {
                selectionRect = selectionRect.union(this._selectedTilesPreview.rect);
            }
            this._selectedTilesPreview.margins = buildTileMargin(selectionRect, this._innerMargin, this._outerMargin, this._workArea);
            this._selectedTilesPreview.openAbove(window, true, selectionRect);
            return GLib.SOURCE_CONTINUE;
        }
        _onWindowGrabEnd(window) {
            this._isGrabbingWindow = false;
            this._tilingLayout.close();
            this._selectedTilesPreview.close();
            this._snapAssist.close();
            this._lastCursorPos = null;
            const isCtrlPressed = (global$1.get_pointer()[2] & clutter10.ModifierType.CONTROL_MASK);
            if (!isCtrlPressed && !this._isSnapAssisting)
                return;
            // disable snap assistance
            this._isSnapAssisting = false;
            // abort if the pointer is moving on another monitor: the user moved
            // the window to another monitor not handled by this tiling manager
            if (!this._isPointerInsideThisMonitor())
                return;
            // abort if there is an invalid selection
            if (this._selectedTilesPreview.innerWidth === 0 || this._selectedTilesPreview.innerHeight === 0) {
                return;
            }
            // apply animations when moving the window
            const windowActor = window.get_compositor_private();
            // @ts-ignore
            windowActor.remove_all_transitions();
            Main.wm._prepareAnimationInfo(global$1.window_manager, windowActor, window.get_frame_rect().copy(), meta10.SizeChange.MAXIMIZE);
            // move and resize the window to the current selection
            window.move_to_monitor(this._monitor.index);
            window.move_frame(true, this._selectedTilesPreview.innerX, this._selectedTilesPreview.innerY);
            window.move_resize_frame(true, this._selectedTilesPreview.innerX, this._selectedTilesPreview.innerY, this._selectedTilesPreview.innerWidth, this._selectedTilesPreview.innerHeight);
            this._selectedTilesPreview.rect = new meta10.Rectangle({ width: 0 });
        }
        _onSnapAssist(hoveredTileRect, widthReference, heightReference) {
            this._debug(`snap assistant hovered tile: x:${hoveredTileRect.x} y:${hoveredTileRect.y} width:${hoveredTileRect.width} height:${hoveredTileRect.height}`);
            // if the mouse is still on the snap assist's layout then do not close selection
            // if there isn't a tile hovered, then close selection
            const noTileIsHovered = !hoveredTileRect || hoveredTileRect.width === 0 || hoveredTileRect.height === 0 || widthReference === 0 || heightReference === 0;
            if (noTileIsHovered) {
                this._selectedTilesPreview.close();
                this._isSnapAssisting = false;
                return;
            }
            // apply proportions. We have the tile size and position relative to the snap layout. We apply
            // the proportions to get tile size and position relative to the work area 
            const scaledRect = new meta10.Rectangle({
                // hoveredTile.x:layoutContainerReference.width = scaledRect.x:workArea.width
                x: this._workArea.x + ((hoveredTileRect.x * this._workArea.width) / widthReference),
                y: this._workArea.y + ((hoveredTileRect.y * this._workArea.height) / heightReference),
                // hoveredTile:layoutContainerReference = scaledRect:workArea
                width: (hoveredTileRect.width * this._workArea.width) / widthReference,
                height: (hoveredTileRect.height * this._workArea.height) / heightReference,
            });
            // ensure the rect doesn't go horizontally beyond the workarea
            if (scaledRect.x + scaledRect.width > this._workArea.width) {
                scaledRect.width -= scaledRect.x + scaledRect.width - this._workArea.x - this._workArea.width;
            }
            // ensure the rect doesn't go vertically beyond the workarea
            if (scaledRect.y + scaledRect.height > this._workArea.height) {
                scaledRect.height -= scaledRect.y + scaledRect.height - this._workArea.y - this._workArea.height;
            }
            this._selectedTilesPreview.margins = buildTileMargin(scaledRect, this._innerMargin, this._outerMargin, this._workArea);
            this._selectedTilesPreview.open(true, scaledRect);
            // if it is the first time snap assisting
            // then ensure the snap assistant is on top of the selection tile preview 
            if (!this._isSnapAssisting) {
                const parent = this._snapAssist.get_parent();
                if (parent && parent === this._selectedTilesPreview.get_parent()) {
                    parent.set_child_above_sibling(this._snapAssist, this._selectedTilesPreview);
                }
            }
            this._isSnapAssisting = true;
        }
        /**
         * Checks if pointer is inside the current monitor
         * @returns true if the pointer is inside the current monitor, false otherwise
         */
        _isPointerInsideThisMonitor() {
            const [x, y] = global$1.get_pointer();
            return x >= this._monitor.x && x <= this._monitor.x + this._monitor.width
                && y >= this._monitor.y && y <= this._monitor.y + this._monitor.height;
        }
    }

    const LAYOUT_HORIZONTAL_TYPE = 0;

    const debug$1 = logger('LayoutsUtils');
    class LayoutsUtils {
        static get configPath() {
            return GLib__default["default"].build_pathv('/', [GLib__default["default"].get_user_config_dir(), 'ModernWindowManager']);
        }
        static get layoutsPath() {
            return GLib__default["default"].build_filenamev([this.configPath, 'layouts.json']);
        }
        static LoadLayouts() {
            const filePath = this.layoutsPath;
            if (!GLib__default["default"].file_test(filePath, GLib__default["default"].FileTest.EXISTS))
                return this._getDefaultLayout();
            try {
                let [ok, contents] = GLib__default["default"].file_get_contents(filePath);
                if (!ok)
                    return new TileGroup({});
                const decoder = new TextDecoder('utf-8');
                let contentsString = decoder.decode(contents);
                const parsed = JSON.parse(contentsString);
                const layouts = parsed.definitions;
                return this._layoutToTileGroup(layouts[0]);
            }
            catch (exception) {
                debug$1(`exception loading layout: ${JSON.stringify(exception)}`);
            }
            return this._getDefaultLayout();
        }
        static _layoutToTileGroup(layout) {
            return new TileGroup({
                perc: layout.length / 100,
                horizontal: layout.type === LAYOUT_HORIZONTAL_TYPE,
                tiles: layout.items ? layout.items.map(LayoutsUtils._layoutToTileGroup) : [],
            });
        }
        static _getDefaultLayout() {
            return new TileGroup({
                tiles: [
                    new TileGroup({ perc: 0.22, horizontal: false, tiles: [
                            new TileGroup({ perc: 0.5 }),
                            new TileGroup({ perc: 0.5 })
                        ] }),
                    new TileGroup({ perc: 0.56 }),
                    new TileGroup({ perc: 0.22, horizontal: false, tiles: [
                            new TileGroup({ perc: 0.5 }),
                            new TileGroup({ perc: 0.5 })
                        ] }),
                ],
            });
        }
    }

    const SIGNAL_WORKAREAS_CHANGED = 'workareas-changed';
    const debug = logger('extension');
    class Extension {
        settings;
        indicator = null;
        tilingManagers = [];
        innerMargin;
        outerMargin;
        _signalWorkareaChangedId = null;
        constructor() {
            this.settings = getCurrentExtensionSettings();
            this.innerMargin = new clutter10.Margin({ top: 16, bottom: 16, left: 16, right: 16 });
            this.outerMargin = this.innerMargin.copy(); //new Margin({top: 32, bottom: 32, left: 32, right: 32});
            debug('extension is initialized');
        }
        createIndicator(availableLayouts, selectedLayoutIndex) {
            if (this.settings.get_boolean('show-indicator')) {
                this.indicator = new Indicator((lay) => this.onLayoutSelected(lay));
                addToStatusArea(this.indicator);
                const hasMargins = this.innerMargin.top > 0 || this.innerMargin.bottom > 0 || this.innerMargin.left > 0 || this.innerMargin.right > 0;
                this.indicator?.setLayouts(availableLayouts, selectedLayoutIndex, hasMargins);
            }
        }
        enable() {
            // for this version we have a custom layout plus three fixed ones
            const availableLayouts = [
                LayoutsUtils.LoadLayouts(),
                new TileGroup({
                    tiles: [
                        new TileGroup({ perc: 0.22 }),
                        new TileGroup({ perc: 0.56 }),
                        new TileGroup({ perc: 0.22 }),
                    ],
                }),
                new TileGroup({
                    tiles: [
                        new TileGroup({ perc: 0.33 }),
                        new TileGroup({ perc: 0.67 }),
                    ],
                }),
                new TileGroup({
                    tiles: [
                        new TileGroup({ perc: 0.67 }),
                        new TileGroup({ perc: 0.33 }),
                    ],
                })
            ];
            this.createIndicator(availableLayouts, 0);
            if (this.tilingManagers = []) {
                debug('building a tiling manager for each monitor');
                this.tilingManagers = getMonitors().map(monitor => new TilingManager(monitor, availableLayouts, 0, this.innerMargin, this.outerMargin));
            }
            this.tilingManagers.forEach(tm => tm.enable());
            this._signalWorkareaChangedId = global.display.connect(SIGNAL_WORKAREAS_CHANGED, () => {
                const allMonitors = getMonitors();
                if (this.tilingManagers.length !== allMonitors.length) {
                    // a monitor was disconnected or a new one was connected
                    this.tilingManagers.forEach(tm => tm.destroy());
                    this.tilingManagers = allMonitors.map(monitor => new TilingManager(monitor, availableLayouts, 0, this.innerMargin, this.outerMargin));
                    this.tilingManagers.forEach(tm => tm.enable());
                    const selectedLayoutIndex = this.indicator?.getSelectedButtonIndex() || 0;
                    this.indicator?.destroy();
                    this.createIndicator(availableLayouts, selectedLayoutIndex);
                }
                else {
                    // same number of monitors, but one or more workareas changed
                    allMonitors.forEach(monitor => {
                        const newWorkArea = Main.layoutManager.getWorkAreaForMonitor(monitor.index);
                        this.tilingManagers[monitor.index].workArea = newWorkArea;
                    });
                }
            });
            debug('extension is enabled');
        }
        disable() {
            this.indicator?.destroy();
            this.indicator = null;
            this.tilingManagers.forEach(tm => tm.destroy());
            this.tilingManagers = [];
            if (this._signalWorkareaChangedId)
                global.display.disconnect(this._signalWorkareaChangedId);
            debug('extension is disabled');
        }
        onLayoutSelected(layout) {
            this.tilingManagers.forEach(tm => tm.setActiveLayout(layout));
        }
    }
    function extension () {
        imports.misc.extensionUtils.initTranslations(getCurrentExtension().metadata.uuid);
        return new Extension();
    }

    return extension;

})(imports.gi.Gio, imports.gi.St, imports.gi.GObject, imports.gi.Clutter, imports.gi.Meta, imports.gi.Shell, imports.gi.GLib);

}
catch(err) {
  log(`[modernwindowmanager] [init] ${err} Stack trace:
${err.stack}`);
  imports.ui.main.notify('modernwindowmanager', `${err}`);
  throw err;
}
